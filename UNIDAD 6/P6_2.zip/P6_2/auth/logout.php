<?php
require_once 'Seguridad.php';

// Simplemente llamamos al método de la clase
Seguridad::cerrarSesion();
?>
